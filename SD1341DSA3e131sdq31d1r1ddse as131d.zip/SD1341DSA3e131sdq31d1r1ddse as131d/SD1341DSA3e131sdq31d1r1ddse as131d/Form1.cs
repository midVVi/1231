using System.Runtime.CompilerServices;

namespace SD1341DSA3e131sdq31d1r1ddse_as131d
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool gameStart = false;
        bool game = false;

        private void button1_Click(object sender, EventArgs e) //�����
        {

            /*panel1.Visible = true;
            panel1.FlatStyle = FlatStyle.Flat;
            panel1.BackColor = Color.Transparent;
            panel1.FlatAppearance.BorderColor = Color.Black;
            panel1.FlatAppearance.BorderSize = 1;
            panel1.FlatAppearance.MouseOverBackColor = Color.Transparent;
*/
           

            game = gameStart == true ? mainLogic(true) : false;
            game = gameStart == true ? false : true;
        }
        int clickDo = 0;
        int click = 1;
        public bool mainLogic(bool game)
        {
            
            return false;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
        }

        public void logicStartGame()
        {
            timer1 
        }
        public void logicTap()
        {

        }
        /*int numInPicBoxName = 0;*/
        int pbNameNum = 0;

        int SizeX = 75;
        int SizeY = 75;

        
        List<PictureBox> ArrPictureBox = new List<PictureBox>();

        async public void positionLogicTap()
        {
            PictureBox pictureBox = new PictureBox();
            pictureBox.Size = new Size(SizeX, SizeY);

            //�������
            pictureBox.Location = new Point(randomLogi�X(), randomLogicY());

            pictureBox.Image = Properties.Resources.birds_PNG43_1933710974;
            pictureBox1.BackColor = Color.Transparent;
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;

            pictureBox.Name = $"pictureBox{pbNameNum++}";
            ArrPictureBox.Add(pictureBox);
        }

        int btNameNum = 0;

        List<Button> ArrButtons = new List<Button>();

        async public void positionLogicBack()
        {
            Button bl = new Button();
            bl.BackColor = Color.DarkGreen;
            bl.FlatStyle = FlatStyle.Flat;
            bl.BackColor = Color.Transparent;
            bl.FlatAppearance.BorderColor = Color.Black;
            bl.FlatAppearance.BorderSize = 1;
            bl.FlatAppearance.MouseOverBackColor = Color.Transparent;

            bl.Size = new Size(randomLogicSize(SizeX), randomLogicSize(SizeY));

            //������� �����
            bl.Location = new Point(thisLocationX + (SizeX / 2), thisLocationY + (SizeY / 2));

            bl.Name = $"bl{btNameNum++}";
            ArrButtons.Add(bl);
        }

        Random random = new Random();
        public int randomLogicA() => random.Next(0, 100);
        public int randomLogicB() => random.Next(0, 10);
        public int randomLogicSize(int sizeStok) => sizeStok + random.Next(25, 50);

        int thisLocationX = 0;
        int thisLocationY = 0;
        public int randomLogi�X() => thisLocationX = random.Next(135, 1000);

        public int randomLogicY() => thisLocationY = random.Next(50, 500);

        private void pictureBox1_Click(object sender, EventArgs e) // �����
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            clickDo++;
        }
    }
}
