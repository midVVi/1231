using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace SD1341DSA3e131sdq31d1r1ddse_as131d
{
    public partial class Form1 : Form
    {
        int score = 0;
        Label scoreLabel;
        Label hitLabel;
        public Form1()
        {
            InitializeComponent();

            timer1.Interval = 1500;
            scoreLabel = new Label();
            scoreLabel.Text = "0";
            scoreLabel.Font = new Font("Arial", 20, FontStyle.Bold);
            scoreLabel.ForeColor = Color.White;
            scoreLabel.BackColor = Color.Transparent;
            scoreLabel.Location = new Point(10, 10);
            scoreLabel.Size = new Size(200, 40);
            this.Controls.Add(scoreLabel);
            scoreLabel.BringToFront();

            
            hitLabel = new Label();
            hitLabel.Font = new Font("Arial", 28, FontStyle.Bold);
            hitLabel.ForeColor = Color.Yellow;
            hitLabel.BackColor = Color.Transparent;
            hitLabel.Size = new Size(300, 50);
            hitLabel.TextAlign = ContentAlignment.MiddleCenter;
            hitLabel.Visible = false;
            this.Controls.Add(hitLabel);
            hitLabel.BringToFront();

            this.KeyDown += Form1_KeyDown;
            this.KeyPreview = true;
        }
        bool gameStart = false;
        bool game = false;
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Z || e.KeyCode == Keys.X)
            {
                if (ArrPictureBox.Count > 0)
                {
                    
                    var bird = ArrPictureBox.FirstOrDefault(b => !b.IsDisposed);
                    var zone = ArrZones.FirstOrDefault(z => !z.IsDisposed);
                    if (bird != null) HitBird(bird, zone);
                }
            }
        }


        async void ShowHitLabel(int points, Point location)
        {
            hitLabel.Text = points == 300 ? "300" : points == 200 ? "200" : "100";
            hitLabel.ForeColor = points == 300 ? Color.Cyan : points == 200 ? Color.Yellow : Color.White;
            hitLabel.Location = new Point(location.X, location.Y - 40);
            hitLabel.Visible = true;
            hitLabel.BringToFront();
            await Task.Delay(800);
            hitLabel.Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!gameStart)
            {
                gameStart = true;
                click = false; 
                mainLogic(true);
            }
        }
        int clickDo = 0;
       // int click = 1;
        public bool mainLogic(bool game)
        {
            logicStartGame();
            return true;
        }
        bool click = false;

       
        int totalBirds = 0;
        int clickedBirds = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (!click && ArrPictureBox.Count > 0)
            {
                logicStopGame();
                foreach (var pb in ArrPictureBox) { this.Controls.Remove(pb); pb.Dispose(); }
                foreach (var z in ArrZones) { this.Controls.Remove(z); z.Dispose(); }
                ArrPictureBox.Clear();
                ArrZones.Clear();
                gameStart = false;
                MessageBox.Show($"��������! ����: {score}\n����� ����� �����.");
                score = 0;
                scoreLabel.Text = "0";
                click = false;
                return;
            }

            foreach (var pb in ArrPictureBox) { this.Controls.Remove(pb); pb.Dispose(); }
            foreach (var z in ArrZones) { this.Controls.Remove(z); z.Dispose(); }
            ArrPictureBox.Clear();
            ArrZones.Clear();

            click = false;

            PictureBox zone = positionLogicTapBack();
            PictureBox bird = positionLogicTap();
            StartShrinkEffect(zone, bird);

            bird.Click += (s, ev) => HitBird(bird, zone);
        }
       

        async void StartShrinkEffect(PictureBox zone, PictureBox bird)
        {
            int startSize = SizeX + 100;
            zone.Size = new Size(startSize, startSize);
            zone.Location = new Point(
                thisLocationX + SizeX / 2 - startSize / 2,
                thisLocationY + SizeY / 2 - startSize / 2
            );

            while (zone.Width > SizeX && !click)
            {
                await Task.Delay(16);
                if (zone.IsDisposed || bird.IsDisposed) return;
                int newSize = zone.Width - 5;
                zone.Size = new Size(newSize, newSize);
                zone.Location = new Point(
                    thisLocationX + SizeX / 2 - newSize / 2,
                    thisLocationY + SizeY / 2 - newSize / 2
                );
            }
        }

        void HitBird(PictureBox bird, PictureBox zone)
        {
            if (bird.IsDisposed) return;
            click = true;

            int points = 100;
            if (zone != null && !zone.IsDisposed)
            {
                int zoneSize = zone.Width - SizeX;
                if (zoneSize <= 10) points = 300;
                else if (zoneSize <= 35) points = 200;
                else points = 100;
            }

            score += points;
            scoreLabel.Text = score.ToString();
            ShowHitLabel(points, bird.Location);

            this.Controls.Remove(bird);
            if (zone != null) this.Controls.Remove(zone);
            if (!bird.IsDisposed) bird.Dispose();
            if (zone != null && !zone.IsDisposed) zone.Dispose();
            ArrPictureBox.Remove(bird);
            if (zone != null) ArrZones.Remove(zone);
        }


        public void logicStartGame()
        {
            timer1.Start(); 
        }
        public void logicStopGame()
        {
            timer1.Stop();
        }
        public void logicTap()
        {

        }
        int pbNameNum = 0;

        int SizeX = 75;
        int SizeY = 75;

        
        List<PictureBox> ArrPictureBox = new List<PictureBox>();
        public PictureBox ClickToPositionLogicTap(PictureBox pictureBox)
        {
            pictureBox.Click += (sender, e) =>
            {
                click = true;
            };
            return pictureBox;
        }
        public bool ClickToPositionLogicTapBack(PictureBox picture, Button button, bool click)
        {
            if (click)
            {
                if (button.Location.X >= picture.Location.X &&
                    button.Location.Y >= picture.Location.Y &&
                    button.Location.X + button.Width <= picture.Location.X + picture.Width &&
                    button.Location.Y + button.Height <= picture.Location.Y + picture.Height)
                {
                    return false;
                }
                
            }
            return true;
        }

        public PictureBox positionLogicTap()
        {
            PictureBox pictureBox = new PictureBox();
            pictureBox.Size = new Size(SizeX, SizeY);
            pictureBox.Location = new Point(randomLogi�X(), randomLogicY());
            pictureBox.Image = Properties.Resources.birds_PNG43_1933710974;
            pictureBox.BackColor = Color.Transparent;
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.BorderStyle = BorderStyle.FixedSingle;
            pictureBox.Name = $"pictureBox{pbNameNum++}";
            ArrPictureBox.Add(pictureBox);
            this.Controls.Add(pictureBox);
            pictureBox.BringToFront();
            return pictureBox;
        }

        int btNameNum = 0;

        List<PictureBox> ArrZones = new List<PictureBox>();

        public PictureBox positionLogicTapBack()
        {
            PictureBox zone = new PictureBox();
            zone.Size = new Size(SizeX + 60, SizeY + 60);
            zone.Location = new Point(thisLocationX - 30, thisLocationY - 30);
            zone.BackColor = Color.Transparent;
            zone.BorderStyle = BorderStyle.FixedSingle;
            zone.Name = $"zone{btNameNum++}";
            ArrZones.Add(zone);
            this.Controls.Add(zone);
            zone.BringToFront();
            return zone;
        }
        Random random = new Random();
        public int randomLogicA() => random.Next(0, 100);
        public int randomLogicB() => random.Next(0, 10);
        public int randomLogicSize(int sizeStok) => sizeStok + random.Next(25, 50);

        int thisLocationX = 0;
        int thisLocationY = 0;
        public int randomLogi�X() => thisLocationX = random.Next(135, 1000);

        public int randomLogicY() => thisLocationY = random.Next(50, 500);

        private void pictureBox1_Click(object sender, EventArgs e) // �����
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            clickDo++;
        }
    }
}
